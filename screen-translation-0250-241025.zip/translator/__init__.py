# This file makes the 'translator' directory a Python package.
