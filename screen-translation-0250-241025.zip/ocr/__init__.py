# This file makes the 'ocr' directory a Python package.
